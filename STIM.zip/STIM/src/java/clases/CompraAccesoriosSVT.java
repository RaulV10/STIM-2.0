/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clases;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Raul V
 */
@WebServlet(name = "CompraAccesoriosSVT", urlPatterns = {"/CompraAccesoriosSVT"})
public class CompraAccesoriosSVT extends HttpServlet {

    private Conexion cnn;
    
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet CompraAccesoriosSVT</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet CompraAccesoriosSVT at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            
            // Recuperar los datos desde el formulario
            
            String idUsuario = request.getSession().getAttribute("username").toString();
            int idAccesorio = Integer.parseInt(request.getParameter("idAccesorio"));
            
            // Instacion del objeto cnn
            cnn = new Conexion();
            
            ResultSet rs_venta;
            rs_venta = cnn.consultar("select precio, dinero from juegos, usuario where idusuario = '" + idUsuario + "' and idaccesorio=" + idAccesorio);
            if(rs_venta.next()) {
                float precio = Float.parseFloat(rs_venta.getString(1));
                float dineroUsuario = Float.parseFloat(rs_venta.getString(2));

                if(dineroUsuario >= precio) {
                    cnn.ejecutarSQL("insert into ventaAccesorios values(null"
                                    + ", '" + idUsuario + "'" 
                                    + ", " + idAccesorio + ""
                                    + ", " + "now())"
                    );

                    float nuevoDineroUsuario = dineroUsuario - precio;
                    cnn.ejecutarSQL("update usuario set dinero = " + nuevoDineroUsuario + " where idusuario = '" + idUsuario + "'");
                    response.sendRedirect("bienvenido.jsp#graciasCompra");

                    cnn.ejecutarSQL("insert into transacciones values(null, '" + idUsuario + "', " + (precio * -1) + ", now()");
                } else {
                    response.sendRedirect("catalogo.jsp#ups");
                }
            }
            
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(CompraAccesoriosSVT.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(CompraAccesoriosSVT.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
