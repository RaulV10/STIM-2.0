/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clases;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.swing.JOptionPane;

/**
 *
 * @author Raul V
 */
@WebServlet(name = "CompraVentaSVT", urlPatterns = {"/CompraVentaSVT"})
public class CompraVentaSVT extends HttpServlet {

    private Conexion cnn;
    
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet CompraVentaSVT</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet CompraVentaSVT at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        try {
            
            // Recuperar los datos desde el formulario
            
            String idUsuario = request.getSession().getAttribute("username").toString();
            int idJuego = Integer.parseInt(request.getParameter("idJuego"));
            String cr = request.getParameter("compraOrenta");
            String claseJuego = request.getParameter("claseJuego");
            float precio_renta = 0;
            
            if(claseJuego.equalsIgnoreCase("Platino")) { precio_renta = 90; }
            else if(claseJuego.equalsIgnoreCase("Plata")) { precio_renta = 70; }
            else if(claseJuego.equalsIgnoreCase("Oro")) { precio_renta = 50; }
            
            // Instacion del objeto cnn
            cnn = new Conexion();
            if(cr.equals("Rentar")) {
                ResultSet rs_renta;
                rs_renta = cnn.consultar("select dinero from usuario where idusuario = '" + idUsuario + "'");
                if(rs_renta.next()) {
                    float dineroUsuario = Float.parseFloat(rs_renta.getString(1));
                    
                    if(dineroUsuario >= precio_renta) {
                        cnn.ejecutarSQL("insert into rentaJuegos values(null"
                                        + ", '" + idUsuario + "'" 
                                        + ", " + idJuego + ""
                                        + ", " + "now()"
                                        + ", " + "now() + interval 6 day)"
                        );
                        
                        float nuevoDineroUsuario = dineroUsuario - precio_renta;
                        cnn.ejecutarSQL("update usuario set dinero = " + nuevoDineroUsuario + " where idusuario = '" + idUsuario + "'");
                        response.sendRedirect("bienvenido.jsp#graciasRenta");
                        
                        cnn.ejecutarSQL("insert into transacciones values(null, '" + idUsuario + "', " + (precio_renta * -1) + ", now())");
                    } else {
                        response.sendRedirect("catalogo_juegos.jsp#ups");
                    }
                }              
            }
            if(cr.equals("Comprar")) {
                ResultSet rs_venta;
                rs_venta = cnn.consultar("select precioventa, dinero from juegos, usuario where idusuario = '" + idUsuario + "' and idjuego=" + idJuego);
                if(rs_venta.next()) {
                    float precioJuego = Float.parseFloat(rs_venta.getString(1));
                    float dineroUsuario = Float.parseFloat(rs_venta.getString(2));
                    
                    if(dineroUsuario >= precioJuego) {
                        cnn.ejecutarSQL("insert into ventaJuegos values(null"
                                        + ", '" + idUsuario + "'" 
                                        + ", " + idJuego + ""
                                        + ", " + "now())"
                        );
                        
                        float nuevoDineroUsuario = dineroUsuario - precioJuego;
                        cnn.ejecutarSQL("update usuario set dinero = " + nuevoDineroUsuario + " where idusuario = '" + idUsuario + "'");
                        response.sendRedirect("bienvenido.jsp#graciasCompra");
                        
                        cnn.ejecutarSQL("insert into transacciones values(null, '" + idUsuario + "', " + (precioJuego * -1) + ", now())");
                    } else {
                        response.sendRedirect("catalogo_juegos.jsp#ups");
                    }
                }
            }
            
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(CompraVentaSVT.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(CompraVentaSVT.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
